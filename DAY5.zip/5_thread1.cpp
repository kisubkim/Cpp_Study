﻿#include <iostream>
#include <thread> 
#include <chrono>
using namespace std::literals;

// this_thread namespace 

int main()
{
    std::cout << std::this_thread::get_id() << std::endl;

    std::this_thread::sleep_for(3s);		

}


