#include <iostream>
#include <vector>
#include <thread>

template<typename T> 
void foo(T a) {}

int main()
{
	// foo 를 호출
	foo(3);

	// #1. foo 를 스레드로 실행해 보세요

	// #2. thread 객체의 copy 와 move
	
}