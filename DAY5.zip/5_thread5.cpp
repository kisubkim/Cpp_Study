﻿// async - 4번 복사
