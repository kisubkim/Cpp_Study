#include <iostream>
#include <string>
#include "show.h"
/*
template< typename CharT,
    	  typename Traits = std::char_traits<CharT>,
          typename Allocator = std::allocator<CharT>> 
class basic_string
{
};
using string = basic_string<char>;
*/

int main()
{
	std::string s = "hello";
}