﻿#include <iostream>
#include <type_traits>

template<typename T> void foo(const T& b)
{
	// 조사

	// 변형된 타입 얻기
}

int main()
{
	int n = 10;

	printv(n);
	printv(&n);
}

