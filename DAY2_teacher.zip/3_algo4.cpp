#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
#include "show.h"

int main()
{
	std::vector<int> v = { 1,2,3,4,5,6,7,8,9,10};
	std::list<int>   s = { 1,2,3,4,5,6,7,8,9,10 };

	// 컨테이너를 뒤집을때 사용하는 함수 이름은 "reverse" 입니다
	// v와 s 를 뒤집어 보세요

	show(v);
	show(s);	


}














