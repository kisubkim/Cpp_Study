#include <stdio.h>

int x = 100;

int main()
{
	const char* s1 = "ABCD";
	const char* s2 = "XYZ";

	printf("ABCD");
}

// 1. 빌드해서 실행파일 만드세요
// 2. 구글에서 "PEView" 검색해서 PEView0.99 다운 받으세요
// 3. PEView 실행해서 실행파일 여세요
