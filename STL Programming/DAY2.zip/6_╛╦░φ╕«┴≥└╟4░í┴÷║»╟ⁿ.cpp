﻿#include <iostream>
#include <vector>
#include <algorithm>
#include "show.h"

int main()
{
	std::vector<int> v1 = { 1,2,3,4,5,6,7,8,9,10 };
	std::vector<int> v2 = { 0,0,0,0,0,0,0,0,0,0 };

	auto p1 = std::remove(v1.begin(), v1.end(), 3);

	show(v1);
	show(v2);
}
