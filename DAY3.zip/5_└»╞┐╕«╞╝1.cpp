﻿#include <iostream>
#include <tuple>
#include "show.h"

int main()
{
	// pair : 서로다른 타입 2개를 보관하는 구조체

}


