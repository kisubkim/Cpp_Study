﻿#include <iostream>
#include <unordered_set>
#include "show.h"

// hash 함수

int main()
{

}

