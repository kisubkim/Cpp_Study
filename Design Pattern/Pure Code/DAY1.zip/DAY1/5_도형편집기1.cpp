﻿// 15page ~ 
#include <iostream>
#include <vector>


int main()
{

}

