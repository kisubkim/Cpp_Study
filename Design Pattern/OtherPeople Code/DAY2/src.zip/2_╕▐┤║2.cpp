﻿#include <iostream>
#include <string>
#include <vector>
#include <conio.h> 

class MenuItem {
	std::string title;
	int id;
public: 
	MenuItem(const std::string title, int id) : title(title), id(id) {}
	std::string get_title() const { return title; }
	void command()
	{
		printf("%s 메뉴 선택됨 \n", get_title().c_str());
		_getch(); //잠시대기
	}
};

int main()
{
	//이름 고유아이디
	MenuItem m1("김밥", 11);
	MenuItem m2("라면", 12);

	m1.command(); 

	int cmd;
	std::cin >> cmd;

	switch (cmd)
	{
	case 1: break;
	case 2: break;
	}

}




