#include <iostream>

// �׻� Ŭ���� ���̾�׷��� �����ϼ���


struct IDraw
{
	virtual void draw() = 0;
	virtual ~IDraw() {}
};

class PhotoSticker : public IDraw
{
public:
	void take() { std::cout << "take Photo\n"; }
	void draw() override { std::cout << "draw Photo\n"; }
};



class Emoticon : public IDraw
{
	IDraw* original;

public:
	Emoticon(PhotoSticker* ps) : original(ps) {}

	void draw() override
	{
		std::cout << "^^\n";
		original->draw();
		std::cout << "^^\n";
	}
};

class Border : public IDraw
{
	IDraw* original;
public:
	Border(IDraw* ps) : original(ps) {}

	void draw() override
	{
		std::cout << "========\n";
		original->draw();
		std::cout << "========\n";
	}
};

int main()
{
	PhotoSticker ps;
	ps.take();
	ps.draw();


	Emoticon e(&ps);
	e.draw();

	Border d(&e);
	d.draw();

}