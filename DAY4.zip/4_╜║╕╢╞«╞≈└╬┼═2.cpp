﻿#include <iostream>

// Ptr 복사해오세요

int main()
{
}


